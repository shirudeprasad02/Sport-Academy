from django.urls import path
from . import views

urlpatterns = [
   
    path('register/', views.register_player, name='register_player'),
    
    path('Chart/', views.player_list, name='player_list'),

    path('update/<int:player_id>/', views.update_player, name='update_player'),

    path('login/', views.user_login, name='user_login'),
]
