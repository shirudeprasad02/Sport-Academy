from django.db import models

# Create your models here.

class Player(models.Model):
    fname = models.CharField(max_length=100)
    lname = models.CharField(max_length=100)
    age = models.IntegerField()
    team = models.CharField(max_length=100)
    position = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.fname} {self.lname}"

